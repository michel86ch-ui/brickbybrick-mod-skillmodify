SkillModify for Brick by Brick
https://github.com/michel86ch-ui/brickbybrick-mod-skillmodify

INSTALL
Unzip everything into the game folder, so that winhttp.dll sits next to BrickByBrick.exe
(Steam: right-click the game > Manage > Browse local files). BepInEx already installed
(e.g. with Extra Buildings)? Just overwrite, the files are the same.

WHAT IT DOES
The last skill levels give more: Strong Arms X carries 50 bricks (game: 20),
Brick Magnet X pulls 50 bricks (game: 10). Values are in
BepInEx\config\michel.brickbybrick.skillmodify.cfg (created at the first game start).
Note: with changed values, every world you open no longer counts for the Steam leaderboard.

UNINSTALL
Delete the folder BepInEx\plugins\SkillModify.

Includes BepInEx 5.4.23.5, unmodified (MIT license: BepInEx\LICENSE-BepInEx.txt).
Unofficial fan mod, not made by the game's developers.
